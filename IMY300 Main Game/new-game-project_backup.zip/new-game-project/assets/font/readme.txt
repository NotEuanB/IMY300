https://caffinate.itch.io/abaddon

Licensed under CC BY 3.0.
Free to use. Attribution not required, but appreciated. 
(don't resell this font or any modified derivatives and we're good)